/********************************************************************************/
/* Copyright (c) 2018 Jason Brewer												*/
/* Spelling Test Functions														*/
/********************************************************************************/
/* Header file for hw1.c															*/
/********************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define MAXSTRING 20
#define WORDCOUNT 9


/// Structs for my list operations
typedef struct node {
    int order;
    char word[MAXSTRING];
    struct node *next;
    struct node *prev;
} node;

typedef struct head {
    node *head;
} head;

void createlist(head * list);
void enlist(head * list, int number, char word[]);
node *delist(head * list, int numberToRemove);
void introduction();
void populateList(head * pointer);
void typingGame(head *headpointer, int randomNumber);
