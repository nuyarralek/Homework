/********************************************************************************/
/* Copyright (c) 2018 Jason Brewer												*/
/* Spelling Test Functions														*/
/********************************************************************************/
/* Functions for hw1.c															*/
/********************************************************************************/

#include "hw1header.h"

void createlist(head * list)
/// Creates the head that will point to the linked list
{
    list->head = malloc(sizeof(node));
    list->head->order = -99;
    list->head->next = NULL;
}

void enlist(head * list, int number, char word[])
/// Points head pointer to elements in the linked list and makes it circular
{
    node *temp, *curr;
    temp = malloc(sizeof(node));
    temp->order = number;
    strcpy(temp->word, word);
    temp->next = NULL;
    temp->prev = NULL;


    if (number == 0) {
	list->head->next = temp;
    }
    if (number == (WORDCOUNT - 1)) {
	curr->next = temp;
	temp->prev = curr;
	temp->next = list->head->next;
	list->head->next->prev = temp;
    }
    if (number != 0 && number != (WORDCOUNT - 1)) {
	curr->next = temp;
	temp->prev = curr;
    }
    curr = temp;
}

node *delist(head * list, int numberToRemove)
/// Removes items from the list and shifts head pointer if what it points to moves
{
    node *temp;
    temp = list->head;
    for (int i = 0; i < WORDCOUNT; i++) {
	if (temp->order == numberToRemove || i == (WORDCOUNT - 1)) {
	    temp->prev->next = temp->next;
	    temp->next->prev = temp->prev;
	    if (list->head->next == temp) {
		list->head->next = temp->next;
	    }
	    break;
	}
	temp = temp->next;
    }
    return temp;
}

void introduction()
/// Text statement explaining the game
{
    printf
	("\nThis is a game that tests typing speed\n\nType the following words:\n");
}

void populateList(head * pointer)
/// Function that assigns words and orders to the linked list
{
    char wordlist[MAXSTRING][WORDCOUNT] =
	{ {"The"}, {"quick"}, {"brown"}, {"fox"}, {"jumps"}, {"over"},
	{"the"},
    {"lazy"}, {"dog"}
    };

    for (int i = 0; i < WORDCOUNT; i++) {
	enlist(pointer, i, wordlist[i]);
    }
}

void typingGame(head *headpointer, int randomNumber)
/// The actual game, takes headpointer to receive words from the list and the randomnumber to modify it
{
    struct timeval answer;		/// A timeval struct to store the times, initialized to 0.
    answer.tv_sec = 0;
    answer.tv_usec = 0;

    for (int i = 0; i < WORDCOUNT; i++) {

	node *temp;
	struct timeval start, stop, result;
	int modNumber = randomNumber % (WORDCOUNT - i); 	/// This is a modification of the random number
	char userInput[MAXSTRING];

	temp = delist(headpointer, modNumber);				/// This call returns a struct from the list based on the modnumber

	while (strcmp(userInput, temp->word) != 0) {
	    printf("  word #%d is %s: ", i + 1, temp->word);
	    gettimeofday(&start, NULL);
	    scanf("%s", userInput);
	    gettimeofday(&stop, NULL);
	    if (strcmp(userInput, temp->word) != 0)
		printf("Incorrect. Try again.\n");
	    timersub(&stop, &start, &result);
	    timeradd(&answer, &result, &answer); /// Iteratively adds times to the answer struct
	}
	free(temp);
    }
    printf("Correct! Your time is: %ld sec %ld usec\n\n", answer.tv_sec,
	   answer.tv_usec);
}

