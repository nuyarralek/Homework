/********************************************************************************/
/* Copyright (c) 2018 Jason Brewer												*/
/* Spelling Test																*/
/********************************************************************************/
/* Randomly selects words from a list and then measures the time it takes		*/
/*  to type them. This program uses a circularly linked list data structure		*/
/* 	to store the data.															*/
/********************************************************************************/


#include "hw1header.h"

int main(int argc, char **argv)
{

    int randomNumber;		/// This is my randomNumber
    int i;					/// Dummy variable
    head headpointer;		/// This will be used for pointing to the list   
    struct timeval time;	/// Struct used for gettimeofday
    gettimeofday(&time, NULL);
    srand(time.tv_usec);	/// Seeding random with gettimeofday
    randomNumber = rand();

    createlist(&headpointer);
    populateList(&headpointer);
    introduction();
    typingGame(&headpointer, randomNumber);

    return 0;
}
